import { useState } from 'react';
import { 
  Search, 
  Building2, 
  MapPin, 
  Link as LinkIcon, 
  Mail, 
  Linkedin, 
  User, 
  Users, 
  Target, 
  Code,
  Loader2,
  Sparkles,
  ArrowRight,
  ChevronRight,
  Info,
  Layers,
  LayoutDashboard,
  Save,
  BarChart3,
  Settings,
  Share2,
  ExternalLink
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import { generateLeads, type Lead, type SearchResult } from './services/geminiService';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Utility for merging classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function App() {
  const [niche, setNiche] = useState('');
  const [location, setLocation] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState<SearchResult | null>(null);
  const [selectedLeadIndex, setSelectedLeadIndex] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'profile' | 'email' | 'tools'>('profile');

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!niche || !location) return;

    setIsLoading(true);
    setError(null);
    try {
      const data = await generateLeads(niche, location);
      setResults(data);
      setSelectedLeadIndex(0);
      setActiveTab('profile');
    } catch (err) {
      setError('Failed to gather leads. Please try again or refine your search.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const selectedLead = results && selectedLeadIndex !== null ? results.leads[selectedLeadIndex] : null;

  return (
    <div className="flex h-screen w-full bg-slate-50 font-sans text-slate-900 overflow-hidden">
      {/* Sidebar */}
      <aside className="hidden md:flex w-64 bg-slate-900 text-white flex-col h-full shrink-0">
        <div className="p-6 flex items-center space-x-3">
          <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center shadow-lg shadow-blue-500/20">
            <Target size={18} className="text-white" />
          </div>
          <span className="text-xl font-bold tracking-tight">LeadScout</span>
        </div>

        <nav className="flex-1 px-4 space-y-1 mt-4">
          <NavItem icon={<LayoutDashboard size={18} />} label="Lead Finder" active />
          <NavItem icon={<Save size={18} />} label="Saved Lists" />
          <NavItem icon={<Mail size={18} />} label="Campaigns" />
          <NavItem icon={<BarChart3 size={18} />} label="Analytics" />
        </nav>

        <div className="p-6 border-t border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-slate-700 rounded-full border border-slate-600 flex items-center justify-center overflow-hidden">
              <User size={20} className="text-slate-400" />
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-medium">B2B Pro</span>
              <span className="text-xs text-slate-500 hover:text-blue-400 cursor-pointer transition-colors underline">Settings</span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full min-w-0">
        {/* Header */}
        <header className="h-16 bg-white border-b border-slate-200 px-8 flex items-center justify-between shadow-sm shrink-0">
          <form className="flex-1 max-w-2xl" onSubmit={handleSearch}>
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <input 
                  type="text" 
                  placeholder="Niche (e.g. SaaS)" 
                  className="w-full bg-slate-100 border-none rounded-full py-2 pl-10 pr-4 text-sm focus:ring-2 focus:ring-blue-500 transition-all"
                  value={niche}
                  onChange={(e) => setNiche(e.target.value)}
                  required
                />
                <Building2 className="absolute left-3.5 top-2.5 w-4 h-4 text-slate-400" />
              </div>
              <div className="relative flex-1">
                <input 
                  type="text" 
                  placeholder="Location (e.g. London)" 
                  className="w-full bg-slate-100 border-none rounded-full py-2 pl-10 pr-4 text-sm focus:ring-2 focus:ring-blue-500 transition-all"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  required
                />
                <MapPin className="absolute left-3.5 top-2.5 w-4 h-4 text-slate-400" />
              </div>
              <button 
                type="submit" 
                disabled={isLoading}
                className="bg-blue-600 text-white rounded-full p-2 hover:bg-blue-700 disabled:opacity-50 transition-all shadow-md shadow-blue-200"
              >
                {isLoading ? <Loader2 size={18} className="animate-spin" /> : <Search size={18} />}
              </button>
            </div>
          </form>

          <div className="flex items-center space-x-4 ml-4 shrink-0">
            <span className="hidden lg:inline text-xs text-slate-500 font-medium">Compliance Mode: <b className="text-green-600">Active</b></span>
            <button className="hidden sm:block bg-slate-900 text-white px-4 py-2 rounded-lg text-sm font-semibold shadow-md whitespace-nowrap">
              Export Results
            </button>
          </div>
        </header>

        {/* Content Body */}
        <div className="flex-1 p-8 overflow-hidden">
          <AnimatePresence mode="wait">
            {isLoading ? (
              <motion.div 
                key="loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="h-full flex flex-col items-center justify-center text-center"
              >
                <div className="relative mb-6">
                  <div className="h-20 w-20 animate-spin rounded-full border-[3px] border-blue-100 border-t-blue-600" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Sparkles className="text-blue-400" size={24} />
                  </div>
                </div>
                <h2 className="text-2xl font-bold text-slate-900">Gathering Leads</h2>
                <p className="text-slate-500 mt-2 max-w-sm">Generating ethical business intelligence for your target niche.</p>
              </motion.div>
            ) : results ? (
              <motion.div 
                key="results"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="h-full grid grid-cols-12 gap-8 overflow-hidden"
              >
                {/* Leads List */}
                <div className="col-span-12 lg:col-span-4 flex flex-col space-y-4 overflow-hidden">
                  <div className="flex items-center justify-between shrink-0">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Identified Leads</h3>
                    <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">{results.leads.length} found</span>
                  </div>
                  <div className="flex-1 overflow-y-auto pr-2 space-y-3 custom-scrollbar">
                    {results.leads.map((lead, idx) => (
                      <div 
                        key={idx}
                        onClick={() => setSelectedLeadIndex(idx)}
                        className={cn(
                          "group p-4 rounded-xl border transition-all cursor-pointer",
                          selectedLeadIndex === idx 
                            ? "bg-white border-blue-200 shadow-lg ring-2 ring-blue-500/10" 
                            : "bg-white border-slate-200 hover:border-blue-300 shadow-sm"
                        )}
                      >
                        <div className="flex justify-between items-start">
                          <span className={cn(
                            "font-bold text-sm transition-colors",
                            selectedLeadIndex === idx ? "text-blue-600" : "text-slate-900 group-hover:text-blue-600"
                          )}>
                            {lead.companyName}
                          </span>
                          <span className="text-[10px] bg-green-50 text-green-700 px-2 py-0.5 rounded-full font-bold">Public</span>
                        </div>
                        <div className="flex items-center gap-2 mt-1.5 text-xs text-slate-500">
                          <span className="truncate">{lead.industry}</span>
                          <span>•</span>
                          <span className="truncate">{lead.location}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Lead Detail View */}
                <div className="col-span-12 lg:col-span-8 bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
                  {selectedLead ? (
                    <>
                      {/* Detail Header */}
                      <div className="p-8 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-6 bg-slate-50/30">
                        <div className="flex items-center space-x-5">
                          <div className="w-16 h-16 bg-blue-600 text-white rounded-2xl flex items-center justify-center font-black text-2xl shadow-lg shadow-blue-200">
                            {selectedLead.companyName.substring(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <h2 className="text-2xl font-black text-slate-900 tracking-tight">{selectedLead.companyName}</h2>
                            <div className="flex items-center space-x-3 text-sm text-blue-600 font-bold mt-1">
                              <a 
                                href={selectedLead.website.startsWith('http') ? selectedLead.website : `https://${selectedLead.website}`} 
                                target="_blank" rel="noreferrer" 
                                className="flex items-center gap-1 hover:underline"
                              >
                                {selectedLead.website} <ExternalLink size={12} />
                              </a>
                              <span className="text-slate-300">|</span>
                              <a 
                                href={selectedLead.linkedin} 
                                target="_blank" rel="noreferrer" 
                                className="flex items-center gap-1 hover:underline"
                              >
                                LinkedIn <Linkedin size={12} />
                              </a>
                            </div>
                          </div>
                        </div>
                        <div className="text-center sm:text-right shrink-0">
                          <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Company Size</p>
                          <p className="font-bold text-slate-900">{selectedLead.size}</p>
                        </div>
                      </div>

                      {/* Detail Tabs */}
                      <div className="px-8 pt-6">
                        <div className="flex items-center gap-6 border-b border-slate-100">
                          {(['profile', 'email', 'tools'] as const).map((tab) => (
                            <button
                              key={tab}
                              onClick={() => setActiveTab(tab)}
                              className={cn(
                                "pb-4 text-xs font-black uppercase tracking-widest transition-all relative",
                                activeTab === tab ? "text-blue-600" : "text-slate-400 hover:text-slate-600"
                              )}
                            >
                              {tab === 'profile' ? 'Lead Profile' : tab === 'email' ? 'Outreach Lab' : 'Pro Methods'}
                              {activeTab === tab && (
                                <motion.div layoutId="tab-underline" className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600" />
                              )}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Detail Content */}
                      <div className="flex-1 p-8 overflow-y-auto">
                        <AnimatePresence mode="wait">
                          {activeTab === 'profile' && (
                            <motion.div 
                              key="profile"
                              initial={{ opacity: 0, x: 10 }}
                              animate={{ opacity: 1, x: 0 }}
                              className="grid md:grid-cols-2 gap-10"
                            >
                              <div>
                                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Decision Maker</h4>
                                <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100 flex items-start gap-4 shadow-sm">
                                  <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center shrink-0">
                                    <User size={20} />
                                  </div>
                                  <div>
                                    <p className="font-bold text-slate-900">{selectedLead.decisionMaker.name}</p>
                                    <p className="text-sm text-slate-600 font-medium">{selectedLead.decisionMaker.role}</p>
                                    {selectedLead.publicEmail && (
                                      <p className="text-sm text-blue-600 mt-2 font-bold flex items-center gap-2">
                                        <Mail size={14} /> {selectedLead.publicEmail}
                                      </p>
                                    )}
                                  </div>
                                </div>

                                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-8 mb-4">Outreach Angle</h4>
                                <div className="bg-blue-50/50 p-5 rounded-2xl border border-blue-100 italic relative">
                                  <Sparkles className="absolute -top-3 -right-3 text-blue-400" size={24} />
                                  <p className="text-sm text-slate-700 leading-relaxed font-medium">
                                    "{selectedLead.outreachAngle}"
                                  </p>
                                </div>
                              </div>
                              <div>
                                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Quick Bio</h4>
                                <p className="text-sm text-slate-600 leading-relaxed font-medium">
                                  {selectedLead.description}
                                </p>

                                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-8 mb-4">Industry Insights</h4>
                                <div className="space-y-2">
                                  <div className="flex items-center gap-2 text-xs font-bold text-slate-600 bg-slate-100 px-3 py-2 rounded-lg">
                                    <Layers size={14} className="text-blue-500" /> {selectedLead.industry}
                                  </div>
                                  <div className="flex items-center gap-2 text-xs font-bold text-slate-600 bg-slate-100 px-3 py-2 rounded-lg">
                                    <MapPin size={14} className="text-blue-500" /> {selectedLead.location}
                                  </div>
                                </div>
                              </div>
                            </motion.div>
                          )}

                          {activeTab === 'email' && (
                            <motion.div 
                              key="email"
                              initial={{ opacity: 0, x: 10 }}
                              animate={{ opacity: 1, x: 0 }}
                              className="h-full"
                            >
                              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-6 font-mono text-xs leading-relaxed text-slate-600 border-l-4 border-l-blue-600">
                                <ReactMarkdown>{results.coldEmailDraft}</ReactMarkdown>
                              </div>
                              <div className="mt-6 flex items-center gap-3 p-4 bg-amber-50 rounded-xl border border-amber-100 text-amber-800">
                                <Info size={18} className="shrink-0" />
                                <p className="text-[11px] font-bold">Pro Tip: Personalize the first line by referencing the specific outreach angle provided in the Profile tab.</p>
                              </div>
                            </motion.div>
                          )}

                          {activeTab === 'tools' && (
                            <motion.div 
                              key="tools"
                              initial={{ opacity: 0, x: 10 }}
                              animate={{ opacity: 1, x: 0 }}
                              className="grid gap-4 sm:grid-cols-2"
                            >
                              {results.searchTips.map((tip, idx) => (
                                <div key={idx} className="p-5 rounded-2xl bg-white border border-slate-200 hover:border-blue-300 transition-all shadow-sm">
                                  <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center mb-3">
                                    <Code size={16} />
                                  </div>
                                  <h5 className="text-xs font-black uppercase text-slate-400 mb-2 tracking-wider">Method #{idx + 1}</h5>
                                  <p className="text-sm font-semibold text-slate-700 leading-relaxed">{tip}</p>
                                </div>
                              ))}
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>

                      {/* Detail Footer */}
                      <div className="mt-auto p-4 bg-slate-50 border-t border-slate-100 flex justify-center space-x-6 shrink-0">
                        <ActionButton icon={<Share2 size={14} />} label="Share Lead" />
                        <ActionButton icon={<Save size={14} />} label="Add to CRM" />
                        <ActionButton icon={<Info size={14} />} label="View Full Report" />
                      </div>
                    </>
                  ) : (
                    <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
                       <Users className="text-slate-200 mb-4" size={48} />
                       <h3 className="text-lg font-bold text-slate-900">No Lead Selected</h3>
                       <p className="text-sm text-slate-500 mt-1">Choose a lead from the list to see detailed intelligence.</p>
                    </div>
                  )}
                </div>
              </motion.div>
            ) : error ? (
              <div className="h-full flex flex-col items-center justify-center text-center">
                <div className="h-16 w-16 bg-red-50 text-red-500 rounded-full flex items-center justify-center mb-4">
                  <Info size={32} />
                </div>
                <h3 className="text-xl font-bold text-slate-900">Search Failed</h3>
                <p className="text-slate-500 mt-2">{error}</p>
                <button 
                  onClick={() => handleSearch({ preventDefault: () => {} } as any)}
                  className="mt-6 font-bold text-blue-600 hover:underline"
                >
                  Retry Discovery
                </button>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center max-w-lg mx-auto">
                <div className="w-24 h-24 bg-blue-50 text-blue-200 rounded-3xl flex items-center justify-center mb-8 rotate-3 shadow-inner">
                  <Search size={48} />
                </div>
                <h2 className="text-3xl font-black text-slate-900 tracking-tight">Ready to Scale?</h2>
                <p className="text-slate-500 mt-4 text-lg font-medium">Enter your target industry and location in the search bar above to generate a high-intent B2B outreach list.</p>
                <div className="mt-10 grid grid-cols-2 gap-4 w-full">
                  <div className="p-4 rounded-2xl bg-white border border-slate-200 text-left">
                     <span className="text-[10px] font-black uppercase text-blue-600 tracking-widest">Ethical Data</span>
                     <p className="text-xs font-bold text-slate-600 mt-1">100% public & legally sourced intelligence.</p>
                  </div>
                  <div className="p-4 rounded-2xl bg-white border border-slate-200 text-left">
                     <span className="text-[10px] font-black uppercase text-blue-600 tracking-widest">Actionable</span>
                     <p className="text-xs font-bold text-slate-600 mt-1">Specific outreach angles for every lead.</p>
                  </div>
                </div>
              </div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}

function NavItem({ icon, label, active = false }: { icon: React.ReactNode; label: string; active?: boolean }) {
  return (
    <div className={cn(
      "px-4 py-2 rounded-lg flex items-center space-x-3 transition-colors cursor-pointer font-semibold text-sm",
      active 
        ? "bg-blue-600 text-white shadow-lg shadow-blue-600/20" 
        : "text-slate-400 hover:bg-slate-800 hover:text-white"
    )}>
      {icon}
      <span>{label}</span>
    </div>
  );
}

function ActionButton({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <button className="flex items-center space-x-2 text-xs font-black uppercase tracking-widest text-slate-500 hover:text-blue-600 transition-colors">
      {icon}
      <span>{label}</span>
    </button>
  );
}

