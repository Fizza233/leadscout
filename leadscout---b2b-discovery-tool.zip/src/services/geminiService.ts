import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface Lead {
  companyName: string;
  industry: string;
  location: string;
  website: string;
  publicEmail: string;
  linkedin: string;
  decisionMaker: {
    name: string;
    role: string;
  };
  size: string;
  description: string;
  outreachAngle: string;
}

export interface SearchResult {
  leads: Lead[];
  searchTips: string[];
  coldEmailDraft: string;
}

export async function generateLeads(niche: string, location: string): Promise<SearchResult> {
  const prompt = `
    You are a professional B2B lead generation assistant.
    Generate a list of 5-7 high-quality, legally compliant business leads for the niche: "${niche}" in location: "${location}".
    
    Requirements:
    - Only use publicly available and ethical data sources.
    - Do NOT generate or guess private personal data (like personal phone numbers).
    - Focus on business contact information only.
    - Provide a suggested outreach angle for each lead.
    - Provide a "Cold Email Draft" at the end for the first lead.
    - Suggest 2-3 tools or methods to find verified emails.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          leads: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                companyName: { type: Type.STRING },
                industry: { type: Type.STRING },
                location: { type: Type.STRING },
                website: { type: Type.STRING },
                publicEmail: { type: Type.STRING, description: "Public business email if available" },
                linkedin: { type: Type.STRING, description: "LinkedIn company page URL" },
                decisionMaker: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    role: { type: Type.STRING }
                  },
                  required: ["name", "role"]
                },
                size: { type: Type.STRING, description: "Estimated company size (e.g. 11-50 employees)" },
                description: { type: Type.STRING, description: "Short business description" },
                outreachAngle: { type: Type.STRING, description: "Why this lead is valuable and how to approach them" }
              },
              required: [
                "companyName", "industry", "location", "website", 
                "linkedin", "decisionMaker", "size", "description", "outreachAngle"
              ]
            }
          },
          searchTips: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Tools or methods to find verified emails"
          },
          coldEmailDraft: {
            type: Type.STRING,
            description: "A professional cold email example for the first lead"
          }
        },
        required: ["leads", "searchTips", "coldEmailDraft"]
      },
      tools: [
        { googleSearch: {} }
      ]
    }
  });

  try {
    return JSON.parse(response.text);
  } catch (e) {
    console.error("Failed to parse Gemini response", e);
    throw new Error("Invalid response format from AI");
  }
}
